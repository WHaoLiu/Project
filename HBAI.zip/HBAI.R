library(tidyverse)
library(haven)
library(ineq)


# path
path   <- "D:/13.study/1.Economic/3.2/project/uk data/SURVEY/HBAI/UKDA-5828-sas/sas/"
path2  <- "D:/13.study/1.Economic/3.2/project/uk data/SURVEY/HBAI/UKDA-3300-stata/stata/stata13/"

# 61- 93

file_list <- c(paste0("ifs", 61:93, ".dta"))


# CALCULATE inequality 
inequality_data <- lapply(file_list, function(file_name) {
  file_path <- paste0(path2, file_name)
  data <- read_dta(file_path)
  
  if (file_name %in% c(paste0("ifs", 61:91, ".dta"))) {
    bhc_col <- "WYD_BHC"
    ahc_col <- "WYD_AHC"
    hbhci_col <- "HBHCI"
    hahci_col <- "HAHCI"
    hes_bhc_col <- "HES_BHC"
    hes_ahc_col <- "HES_AHC"
  } else {
    bhc_col <- "wyd_bhc"
    ahc_col <- "wyd_ahc"
    hbhci_col <- "hbhci"
    hahci_col <- "hahci"
    hes_bhc_col <- "hes_bhc"
    hes_ahc_col <- "hes_ahc"
  }
  data <- data %>%
    mutate(Adjusted_BHC = (!!sym(hbhci_col) * !!sym(bhc_col)) / !!sym(hes_bhc_col),
           Adjusted_AHC = (!!sym(hahci_col) * !!sym(ahc_col)) / !!sym(hes_ahc_col))
  
  # 过滤掉负值或零值
  data <- data %>%
    filter(Adjusted_BHC > 0, Adjusted_AHC > 0) %>%
    mutate(LOG_BHC = log(Adjusted_BHC),
           LOG_AHC = log(Adjusted_AHC))
  
  gini_bhc <- ineq(data$Adjusted_BHC, type = "Gini")
  gini_ahc <- ineq(data$Adjusted_AHC, type = "Gini")
  sd_log_bhc <- sd(data$LOG_BHC, na.rm = TRUE)
  sd_log_ahc <- sd(data$LOG_AHC, na.rm = TRUE)
  p90_log_bhc <- quantile(data$LOG_BHC, 0.9, na.rm = TRUE)
  p10_log_bhc <- quantile(data$LOG_BHC, 0.1, na.rm = TRUE)
  p90_log_ahc <- quantile(data$LOG_AHC, 0.9, na.rm = TRUE)
  p10_log_ahc <- quantile(data$LOG_AHC, 0.1, na.rm = TRUE)
  diff_p90_p10_bhc <- p90_log_bhc - p10_log_bhc
  diff_p90_p10_ahc <- p90_log_ahc - p10_log_ahc
  
  year <- as.numeric(substr(file_name, 4, 5)) + 1900
  return(data.frame(Year = year,
                    GINI_BHC = gini_bhc,
                    GINI_AHC = gini_ahc,
                    SD_LOG_BHC = sd_log_bhc,
                    SD_LOG_AHC = sd_log_ahc,
                    P90_LOG_BHC = p90_log_bhc,
                    P10_LOG_BHC = p10_log_bhc,
                    P90_LOG_AHC = p90_log_ahc,
                    P10_LOG_AHC = p10_log_ahc,
                    DIFF_P90_P10_BHC = diff_p90_p10_bhc,
                    DIFF_P90_P10_AHC = diff_p90_p10_ahc))
}) %>% bind_rows()





# 94-21

# input data
i9497e_2122prices <- read_sas(paste0(path, "i9497e_2122prices.sas7bdat"))
i9700e_2122prices <- read_sas(paste0(path, "i9700e_2122prices.sas7bdat"))
i0003e_2122prices <- read_sas(paste0(path, "i0003e_2122prices.sas7bdat"))
i0306e_2122prices <- read_sas(paste0(path, "i0306e_2122prices.sas7bdat"))
i0609e_2122prices <- read_sas(paste0(path, "i0609e_2122prices.sas7bdat"))
i0912e_2122prices <- read_sas(paste0(path, "i0912e_2122prices.sas7bdat"))
i1215e_2122prices <- read_sas(paste0(path, "i1215e_2122prices.sas7bdat"))
i1518e_2122prices <- read_sas(paste0(path, "i1518e_2122prices.sas7bdat"))
i1821e_2122prices <- read_sas(paste0(path, "i1821e_2122prices.sas7bdat"))
i2122e_2122prices <- read_sas(paste0(path, "i2122e_2122prices.sas7bdat"))

# combine
allind_2122prices <- bind_rows(
  i9497e_2122prices,
  i9700e_2122prices,
  i0003e_2122prices,
  i0306e_2122prices,
  i0609e_2122prices,
  i0912e_2122prices,
  i1215e_2122prices,
  i1518e_2122prices,
  i1821e_2122prices,
  i2122e_2122prices
)


# find necessary data
subset_data <- subset(allind_2122prices, 
                      select = c(OE_BHC, OE_AHC, YEAR, YEARFIN))

# CALCULATE inequality
results <- subset_data %>%
  filter(OE_BHC > 0, OE_AHC > 0) %>%
  mutate(LOG_BHC = log(OE_BHC),
         LOG_AHC = log(OE_AHC)) %>%
  group_by(YEAR) %>%
  summarise(GINI_BHC = ineq(OE_BHC, type = "Gini"),
            GINI_AHC = ineq(OE_AHC, type = "Gini"),
            SD_LOG_BHC = sd(LOG_BHC, na.rm = TRUE),
            SD_LOG_AHC = sd(LOG_AHC, na.rm = TRUE),
            P90_LOG_BHC = quantile(LOG_BHC, 0.9, na.rm = TRUE),
            P10_LOG_BHC = quantile(LOG_BHC, 0.1, na.rm = TRUE),
            P90_LOG_AHC = quantile(LOG_AHC, 0.9, na.rm = TRUE),
            P10_LOG_AHC = quantile(LOG_AHC, 0.1, na.rm = TRUE)) %>%
  mutate(DIFF_P90_P10_BHC = P90_LOG_BHC - P10_LOG_BHC,
         DIFF_P90_P10_AHC = P90_LOG_AHC - P10_LOG_AHC)

results <- results %>%
  mutate(YEAR = 1994:2021)

results <- results %>%
  rename(Year = YEAR)

# combine two

HBAI <- bind_rows(inequality_data,results)

library(ggplot2)

ggplot(HBAI, aes(x = Year)) +
  geom_line(aes(y = GINI_BHC, color = "BHC")) +
  geom_line(aes(y = GINI_AHC, color = "AHC")) +
  labs(title = "Gini Coefficients Over Time",
       x = "Year",
       y = "Gini Coefficient",
       color = "Income Type") +scale_x_continuous(breaks = seq(min(HBAI$Year), max(HBAI$Year), by = 4))+
  theme_minimal()

ggplot(HBAI, aes(x = Year)) +
  geom_line(aes(y = SD_LOG_BHC, color = "BHC")) +
  geom_line(aes(y = SD_LOG_AHC, color = "AHC")) +
  labs(title = "SD_LOG Over Time",
       x = "Year",
       y = "SD_LOG",
       color = "Income Type") +scale_x_continuous(breaks = seq(min(HBAI$Year), max(HBAI$Year), by = 4))+
  theme_minimal()

ggplot(HBAI, aes(x = Year)) +
  geom_line(aes(y = DIFF_P90_P10_BHC, color = "BHC")) +
  geom_line(aes(y = DIFF_P90_P10_AHC, color = "AHC")) +
  labs(title = "DIFF_P90_P10 Over Time",
       x = "Year",
       y = "DIFF_P90_P10",
       color = "Income Type") +scale_x_continuous(breaks = seq(min(HBAI$Year), max(HBAI$Year), by = 4))+
  theme_minimal()

