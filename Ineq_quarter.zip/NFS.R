getwd()
setwd("D:/13.study/1.Economic/3.2/project/uk data/SURVEY/NFS")
NFS <- paste0("h1", seq(1974, 2000))

save(list = NFS, file = "NFS.RData")
load("NFS.RData")

# function
library(ineq)
library(dplyr)
library(tidyr)
library(ggplot2)

process_dataset <- function(data) {
  names(data) <- tolower(names(data))
  
  # 1. Remove NA values only from styr, stmth, and finc variables
  data <- drop_na(data, styr, stmth, finc)
  
  # 2. Add a quarter variable for each dataset
  data <- mutate(data, quarter = ceiling(stmth / 3))
  
  # 3. Group data by quarter and calculate inequality indicators
  results <- data %>%
    group_by(styr, quarter) %>%
    summarize(
      GINI = ineq::Gini(finc),
      log_sd = sd(log(finc)),
      log_income_diff = diff(quantile(log(finc), probs = c(0.1, 0.9)))
    )
  
  return(results)
}

# Dataset list
dataset_names <- paste0("h1", seq(1974, 2000))
datasets <- lapply(dataset_names, get)

# Process all datasets
results_list <- lapply(datasets, process_dataset)

# Combine all results
all_results <- bind_rows(results_list, .id = "dataset_name")

# Create a new column with the format "1974Q1", "1974Q2", etc.
all_results <- mutate(all_results, period = paste(styr, "Q", quarter, sep=""))

# Select columns and reorder
all_results <- select(all_results, period, GINI, log_sd, log_income_diff)

# View the results
print(all_results)

custom_x_axis_labels <- function(periods) {
  years <- seq(1974, 2000)
  labels <- paste0(years, "Q1")
  return(labels[labels %in% periods])
}

# GINI
ggplot(all_results, aes(x = period, y = GINI, group = 1)) +
  geom_line(color = "blue") +
  scale_x_discrete(breaks = custom_x_axis_labels(all_results$period)) +
  labs(
    title = "GINI Coefficient Over Time",
    x = "Time (Quarters)",
    y = "GINI Coefficient"
  ) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# Log Standard Deviation
ggplot(all_results, aes(x = period, y = log_sd, group = 1)) +
  geom_line(color = "red") +
  scale_x_discrete(breaks = custom_x_axis_labels(all_results$period)) +
  labs(
    title = "Log Standard Deviation of Income Over Time",
    x = "Time (Quarters)",
    y = "Log Standard Deviation"
  ) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# Log Income Difference (90th percentile - 10th percentile)
ggplot(all_results, aes(x = period, y = log_income_diff, group = 1)) +
  geom_line(color = "blue") +
  scale_x_discrete(breaks = custom_x_axis_labels(all_results$period)) +
  labs(
    title = "Log Income Difference (90th - 10th Percentile) Over Time",
    x = "Time (Quarters)",
    y = "Log Income Difference"
  ) +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

